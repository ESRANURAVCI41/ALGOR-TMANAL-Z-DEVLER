﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Kullanıcıdan bir sayı istenir ve bu sayı bir değişkene atanır...
        Console.Write("Bir sayı girin: ");
        int n = Convert.ToInt32(Console.ReadLine());

        // Girilen sayının faktöriyeli hesaplanır..
        long sonuc = CalculateFactorial(n);

        // Hesaplanan faktöriyel ekrana yazdırılır
        Console.WriteLine("Faktöriyel: " + sonuc);
        Console.ReadLine();
    }

    // Faktöriyel hesaplama işlemini gerçekleştiren metot (rekürsif)...
    static long CalculateFactorial(int n)
    {
        // Eğer n sıfırsa, faktöriyel 1'dir...
        if (n == 0)
        {
            return 1;
        }
        // Eğer n pozitif bir sayı ise, faktöriyel hesaplanır...
        else
        {
            return n * CalculateFactorial(n - 1);
        }
    }
}
