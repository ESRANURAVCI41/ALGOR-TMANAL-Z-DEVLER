﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Faktöriyelini hesaplamak istediğiniz sayıyı girin: ");
        int sayi = Convert.ToInt32(Console.ReadLine());

        long faktoriyel = 1;

        for (int i = 1; i <= sayi; i++)
        {
            faktoriyel *= i;
        }

        Console.WriteLine("{0} sayısının faktöriyeli: {1}", sayi, faktoriyel);
        Console.ReadLine();
    }
}
