﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Kullanıcıdan bir sayı istenir ve bu sayı bir değişkene atanır...
        Console.Write("Bir sayı girin: ");
        int n = Convert.ToInt32(Console.ReadLine());

        // Girilen sayının faktöriyeli hesaplanır ve sonuç bir değişkene atanır...
        long sonuc = CalculateFactorial(n);

        // Hesaplanan faktöriyel ekrana yazdırılır...
        Console.WriteLine("Faktöriyel: " + sonuc);
    }

    // Faktöriyel hesaplama işlemini gerçekleştiren metotu tanımlayalım...
    static long CalculateFactorial(int n)
    {
        // Faktöriyel hesaplama işlemi için bir değişken oluşturulur ve 1 ile başlatılır...
        long sonuc = 1;

        // 1'den başlayarak n'e kadar olan tüm sayılar üzerinde döngü yapılır...
        for (int i = 1; i <= n; i++)
        {
            // Her döngü adımında sonuç değişkeni ile döngü değişkeni çarpılır...
            sonuc *= i;
        }

        // Sonuç değişkeni döngü sonunda faktöriyeli içerir ve geri döndürülür...
        return sonuc;
    }
}


