﻿using System;
using System.Collections.Generic;

class DijkstraAlgoritmasi
{
    public static int[] Dijkstra(int[,] grafik, int kaynak, int dugumSayisi)
    {
        // En kısa mesafeleri tutan dizi...
        int[] mesafe = new int[dugumSayisi];
        bool[] kisaYolSeti = new bool[dugumSayisi];

        // Tüm mesafeleri sonsuz olarak başlat...
        for (int i = 0; i < dugumSayisi; i++)
            mesafe[i] = int.MaxValue;

        // Kaynak düğümün mesafesi 0'dır.
        mesafe[kaynak] = 0;

        // Düğüm sayısı kadar döngü...
        for (int count = 0; count < dugumSayisi - 1; count++)
        {
            // En kısa mesafeyi henüz ziyaret edilmemiş düğümden seçsin...
            int u = MinMesafe(mesafe, kisaYolSeti, dugumSayisi);

            // Seçilen düğümü ziyaret edilmiş olarak işaretle.
            kisaYolSeti[u] = true;

            // Seçilen düğümün komşularını günceller.
            for (int v = 0; v < dugumSayisi; v++)
                if (!kisaYolSeti[v] && grafik[u, v] != 0 && mesafe[u] != int.MaxValue && mesafe[u] + grafik[u, v] < mesafe[v])
                    mesafe[v] = mesafe[u] + grafik[u, v];
        }

        return mesafe;
    }

    // Henüz ziyaret edilmemiş en kısa mesafeye sahip düğümü bul.
    public static int MinMesafe(int[] mesafe, bool[] kisaYolSeti, int dugumSayisi)
    {
        int min = int.MaxValue, minIndex = -1;

        for (int v = 0; v < dugumSayisi; v++)
            if (!kisaYolSeti[v] && mesafe[v] <= min)
            {
                min = mesafe[v];
                minIndex = v;
            }

        return minIndex;
    }
      static void Main(string[] args)
    {
        int[,] grafik = {
            { 0, 10, 0, 0, 0, 0 },
            { 10, 0, 5, 0, 0, 0 },
            { 0, 5, 0, 20, 1, 0 },
            { 0, 0, 20, 0, 2, 5 },
            { 0, 0, 1, 2, 0, 10 },
            { 0, 0, 0, 5, 10, 0 }
        };

        // Düğüm sayısını belirler.
        int dugumSayisi = 6;

        // Kaynak düğümü belirler.
        int kaynak = 0;

        // Dijkstra algoritmasını çalıştır ve sonucu al.
        int[] mesafeler = Dijkstra(grafik, kaynak, dugumSayisi);

        // Sonucu yazdır.
        Console.WriteLine("Düğüm\tMesafe");
        for (int i = 0; i < dugumSayisi; i++)
            Console.WriteLine($"{i}\t{mesafeler[i]}");
        Console.ReadLine();
    }
    
}
