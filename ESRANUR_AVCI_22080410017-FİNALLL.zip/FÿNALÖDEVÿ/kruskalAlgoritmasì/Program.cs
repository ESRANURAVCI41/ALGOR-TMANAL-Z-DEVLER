﻿using System;
using System.Collections.Generic;

class KruskalAlgoritmasi
{
    // Kenar sınıfı, kenarları ve ağırlıklarını temsil eder.
    public class Kenar : IComparable<Kenar>
    {
        public int Kaynak { get; set; } // Kenarın başlangıç düğümü.
        public int Hedef { get; set; }  // Kenarın bitiş düğümü.
        public int Agirlik { get; set; } // Kenarın ağırlığı.

        // Kenarları ağırlıklarına göre karşılaştırmak için CompareTo metodunu implement edelim.
        public int CompareTo(Kenar other)
        {
            return this.Agirlik.CompareTo(other.Agirlik); // Ağırlığa göre karşılaştırma.
        }
    }

    // Birleşim-Bulma (Union-Find) sınıfı, küme işlemlerini yönetir.
    public class UnionFind
    {
        private int[] ebeveyn, derece; // ebeveyn ve derece dizileri.

        // Union-Find yapısını başlatır.
        public UnionFind(int n)
        {
            ebeveyn = new int[n]; // ebeveyn dizisini başlat.
            derece = new int[n];  // derece dizisini başlat.
            for (int i = 0; i < n; i++)
            {
                ebeveyn[i] = i; // Her düğüm başlangıçta kendi ebeveyni.
                derece[i] = 0;  // Başlangıçta tüm düğümlerin derecesi 0.
            }
        }

        // Bir düğümün kökünü bulur ve yol sıkıştırma (path compression) uygular.
        public int Bul(int i)
        {
            if (ebeveyn[i] != i)
                ebeveyn[i] = Bul(ebeveyn[i]); // Yol sıkıştırma.
            return ebeveyn[i]; // Kök düğümü döndür.
        }

        // İki kümeyi birleştirir.
        public void Birlesme(int i, int j)
        {
            int kokI = Bul(i); // İlk düğümün kökünü bul.
            int kokJ = Bul(j); // İkinci düğümün kökünü bul.
            if (kokI != kokJ)
            {
                if (derece[kokI] > derece[kokJ]) // Dereceleri karşılaştır.
                    ebeveyn[kokJ] = kokI; // Daha düşük dereceyi daha yüksek dereceye bağladım.
                else if (derece[kokI] < derece[kokJ])
                    ebeveyn[kokI] = kokJ;
                else
                {
                    ebeveyn[kokJ] = kokI; // Dereceler eşitse birini diğerine bağla ve derecesini arttır.
                    derece[kokI]++;
                }
            }
        }
    }
//kruskal algoritmasıyla MST oluşturma.
    public static List<Kenar> Kruskal(int[,] grafik, int dugumSayisi)
    {
        List<Kenar> kenarlar = new List<Kenar>(); // Tüm kenarları saklamak için bir liste oluşturdum.

        // Tüm kenarları listeye ekler.
        for (int i = 0; i < dugumSayisi; i++)
        {
            for (int j = 0; j < dugumSayisi; j++)
            {
                if (grafik[i, j] != 0) // Sıfır olmayan kenarları ekle.
                    kenarlar.Add(new Kenar { Kaynak = i, Hedef = j, Agirlik = grafik[i, j] });
            }
        }

        // Kenarları ağırlıklarına göre sıralar.
        kenarlar.Sort();

        // Birleşim-Bulma yapısını başlatalım.
        UnionFind uf = new UnionFind(dugumSayisi);

        List<Kenar> mst = new List<Kenar>(); // MST'yi saklamak için bir liste.

        // Kenarları sırayla dolaş ve MST'ye ekle.
        foreach (var kenar in kenarlar)
        {
            int kok1 = uf.Bul(kenar.Kaynak); // Kenarın kaynak düğümünün kökünü bulur.
            int kok2 = uf.Bul(kenar.Hedef);  // Kenarın hedef düğümünün kökünü bulur.

            // Eğer döngü oluşturmayacaksa kenarı ekle.
            if (kok1 != kok2)
            {
                mst.Add(kenar); // Kenarı MST'ye ekle.
                uf.Birlesme(kok1, kok2); // Kümeleri birleştir.
            }
        }
        return mst; // MST'yi döndürür.
    }

    static void Main(string[] args)
    {
        // Grafiği tanımla (komşuluk matrisi).
        int[,] grafik = {
            { 0, 2, 0, 6, 0 },
            { 2, 0, 3, 8, 5 },
            { 0, 3, 0, 0, 7 },
            { 6, 8, 0, 0, 9 },
            { 0, 5, 7, 9, 0 }
        };

        int dugumSayisi = 5; // Düğüm sayısını tanımladım.

        // Kruskal algoritmasını çalıştır ve MST'yi al.
        List<Kenar> mst = Kruskal(grafik, dugumSayisi);

        // MST kenarlarını yazdır.
        Console.WriteLine("MST Kenarları:");
        foreach (var kenar in mst)
        {
            Console.WriteLine($"{kenar.Kaynak} - {kenar.Hedef}: {kenar.Agirlik}");
        }
       
        Console.ReadLine(); 
    }
}
