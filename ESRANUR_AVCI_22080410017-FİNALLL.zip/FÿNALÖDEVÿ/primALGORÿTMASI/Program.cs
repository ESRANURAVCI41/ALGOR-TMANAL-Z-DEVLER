﻿using System;
using System.Collections.Generic;

class PrimAlgoritmasi
{
    // Kenarları temsil eden sınıfı tanımlayalım.
    public class Kenar
    {
        public int Kaynak { get; set; }
        public int Hedef { get; set; }
        public int Agirlik { get; set; }
    }

    // Prim algoritmasını çalıştıran metod...
    public static List<Kenar> Prim(int[,] grafik, int dugumSayisi)
    {
        // MST için kenarları tutacak liste.
        List<Kenar> sonuc = new List<Kenar>();

        // Ziyaret edilen düğümleri tutan dizi.
        bool[] mstIcindekiDugumler = new bool[dugumSayisi];
        mstIcindekiDugumler[0] = true;

        // Kenarları sıralamak için Min-Heap kullanımı.
        List<Kenar> kenarlar = new List<Kenar>();

        // Başlangıç düğümünden tüm kenarları ekleyelim..
        for (int i = 1; i < dugumSayisi; i++)
        {
            if (grafik[0, i] != 0)
                kenarlar.Add(new Kenar { Kaynak = 0, Hedef = i, Agirlik = grafik[0, i] });
        }

        // Kenarları ağırlıklara göre sıralayalım...
        kenarlar.Sort((e1, e2) => e1.Agirlik.CompareTo(e2.Agirlik));

        while (kenarlar.Count > 0)
        {
            // En düşük ağırlıklı kenarı seçelim.
            Kenar kenar = kenarlar[0];
            kenarlar.RemoveAt(0);

            // Eğer hedef düğüm zaten MST içinde değilse,
            if (!mstIcindekiDugumler[kenar.Hedef])
            {
                // Kenarı sonuçlara ekle ve düğümü MST'ye dahil et.
                sonuc.Add(kenar);
                mstIcindekiDugumler[kenar.Hedef] = true;

                // Yeni düğümden çıkan kenarları listeye ekle...
                for (int i = 0; i < dugumSayisi; i++)
                {
                    if (grafik[kenar.Hedef, i] != 0 && !mstIcindekiDugumler[i])
                        kenarlar.Add(new Kenar { Kaynak = kenar.Hedef, Hedef = i, Agirlik = grafik[kenar.Hedef, i] });
                }

                // Kenarları tekrar sırala...
                kenarlar.Sort((e1, e2) => e1.Agirlik.CompareTo(e2.Agirlik));
            }
        }

        return sonuc;//sonucu döndürür...
    }

    static void Main(string[] args)
    {
        int[,] grafik = {
            { 0, 2, 0, 6, 0 },
            { 3, 0, 6, 8, 5 },
            { 5, 3, 1, 1, 7 },
            { 9, 8, 0, 0, 5 },
            { 0, 5, 7, 9, 0 }
        };

        // Düğüm sayısını belirle...
        int dugumSayisi = 5;

        // Prim algoritmasını çalıştır ve sonucu al...
        List<Kenar> mst = Prim(grafik, dugumSayisi);

        // Sonucu yazdıralım..
        Console.WriteLine("MST Kenarları:");
        foreach (var kenar in mst)
        {
            Console.WriteLine($"{kenar.Kaynak} - {kenar.Hedef}: {kenar.Agirlik}");
        }
        Console.ReadLine();
    }
}
