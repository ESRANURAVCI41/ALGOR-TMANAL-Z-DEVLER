﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Örnek matrisler
        int[,] matris1 = { { 2, 2, 3 }, { 5, 5, 6 }, { 7, 8, 9 } };
        int[,] matris2 = { { 6, 8, 7 }, { 6, 5, 4 }, { 9, 2, 1 } };

        // Matrisleri çarparak sonucu hesapla
        int[,] sonuc = CarpMatris(matris1, matris2);

        // Sonucu ekrana yazdır
        for (int i = 0; i < sonuc.GetLength(0); i++)
        {
            for (int j = 0; j < sonuc.GetLength(1); j++)
            {
                Console.Write(sonuc[i, j] + " ");
            }
            Console.WriteLine();
            Console.ReadLine();
        }
    }

    // İki matrisin çarpımını gerçekleştiren fonksiyon
    static int[,] CarpMatris(int[,] matris1, int[,] matris2)
    {
        // Matrislerin çarpılabilirliğini kontrol et
        if (matris1.GetLength(1) != matris2.GetLength(0))
        {
            Console.WriteLine("Bu matrislerle çarpım yapılamaz.");
            return null;
        }

        // Sonuç matrisini oluştur
        int[,] sonuc = new int[matris1.GetLength(0), matris2.GetLength(1)];

        // Matris çarpımını hesapla (özyinelemeli metot çağrısı)
        MatrisCarpimiRecursive(matris1, matris2, sonuc, 0, 0, 0);

        return sonuc;
    }

    // Matris çarpımını özyinelemeli olarak hesaplayan yardımcı fonksiyon
    static void MatrisCarpimiRecursive(int[,] matris1, int[,] matris2, int[,] sonuc, int satir, int sutun, int index)
    {
        // Satır indeksi matrisin boyutunu aşıyorsa geri dön
        if (satir >= matris1.GetLength(0)) return;

        // Sütun indeksi, matris2'nin sütun sayısını aşmıyorsa devam et
        if (sutun < matris2.GetLength(1))
        {
            // İç çarpımın sonucuna katkı yap
            if (index < matris1.GetLength(1))
            {
                sonuc[satir, sutun] += matris1[satir, index] * matris2[index, sutun];
                MatrisCarpimiRecursive(matris1, matris2, sonuc, satir, sutun, index + 1); // Bir sonraki iç çarpım elemanına geç
            }

            MatrisCarpimiRecursive(matris1, matris2, sonuc, satir, sutun + 1, 0); // Bir sonraki sütuna geç
        }
        else
        {
            MatrisCarpimiRecursive(matris1, matris2, sonuc, satir + 1, 0, 0); // Bir sonraki satıra geç
        }
    }
}
