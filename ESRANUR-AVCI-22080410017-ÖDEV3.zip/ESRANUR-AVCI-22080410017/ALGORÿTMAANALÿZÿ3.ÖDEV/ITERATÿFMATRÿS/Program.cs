﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Örnek matrisler
        int[,] matris1 = { { 1, 7, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
        int[,] matris2 = { { 9, 7, 7 }, { 5, 5, 4 }, { 3, 2, 1 } };

        // Matrisleri çarparak sonucu hesapla
        int[,] sonuc = CarpMatris(matris1, matris2);

        // Sonucu ekrana yazdır
        for (int i = 0; i < sonuc.GetLength(0); i++)
        {
            for (int j = 0; j < sonuc.GetLength(1); j++)
            {
                Console.Write(sonuc[i, j] + " ");
            }
            Console.WriteLine();
            Console.ReadLine();
        }
    }

    // İki matrisin çarpımını gerçekleştiren fonksiyon
    static int[,] CarpMatris(int[,] matris1, int[,] matris2)
    {
        // Matrislerin çarpılabilirliğini kontrol et
        if (matris1.GetLength(1) != matris2.GetLength(0))
        {
            Console.WriteLine("Bu matrislerle çarpım yapılamaz.");
            return null;
        }

        // Sonuç matrisini oluştur
        int[,] sonuc = new int[matris1.GetLength(0), matris2.GetLength(1)];

        // Matris çarpımını hesapla (iteratif yöntem)
        for (int i = 0; i < matris1.GetLength(0); i++) // matris1'in satırlarını dolaş
        {
            for (int j = 0; j < matris2.GetLength(1); j++) // matris2'nin sütunlarını dolaş
            {
                sonuc[i, j] = 0; // sonucun ilgili elemanını sıfırla
                for (int k = 0; k < matris1.GetLength(1); k++) // iç çarpım için matris1'in sütunlarını ve matris2'nin satırlarını dolaş
                {
                    sonuc[i, j] += matris1[i, k] * matris2[k, j]; // çarpma işlemini gerçekleştir
                }
            }
        }

        return sonuc; // sonuc matrisini döndür
    }
}


